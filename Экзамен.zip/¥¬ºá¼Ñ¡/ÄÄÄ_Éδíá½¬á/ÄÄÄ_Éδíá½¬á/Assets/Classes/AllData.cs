﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ООО_Рыбалка.Assets.Classes
{
    class AllData
    {
        public static int ID;
    }
}
